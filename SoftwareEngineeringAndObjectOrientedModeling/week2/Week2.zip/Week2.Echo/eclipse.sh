#!/bin/sh
export JAVA_HOME=/homex/opt/jdk1.8.0_31/
PATH=$PATH:$JAVA_HOME/bin
/homex/opt/eclipse-mars/eclipse 
