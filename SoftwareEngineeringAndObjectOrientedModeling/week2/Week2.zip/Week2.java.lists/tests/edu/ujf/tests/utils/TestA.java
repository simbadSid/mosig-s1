package edu.ujf.tests.utils;
import static org.junit.Assert.*;
import org.junit.Test;

/**
 * This is just an example of to fail a test...
 *
 * @author Pr. Olivier Gruber <olivier dot gruber @ acm dot org>
 */
public class TestA {

  @Test
  public void test() {
    fail("Not yet implemented");
  }

}
